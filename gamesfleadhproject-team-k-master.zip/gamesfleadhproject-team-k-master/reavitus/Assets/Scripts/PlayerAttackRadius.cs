using UnityEngine;

public class PlayerAttackRadius : MonoBehaviour
{

    public int attackDamage = 1;



    void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "F")
        {
            ItemHealth1 itemHealth = collision.gameObject.GetComponent<ItemHealth1>();

            itemHealth.Hit(attackDamage);
        }
    }
}
