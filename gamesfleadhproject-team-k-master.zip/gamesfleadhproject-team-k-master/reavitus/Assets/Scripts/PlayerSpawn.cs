using UnityEngine;
using UnityEngine.InputSystem;

public class PlayerSpawn : MonoBehaviour
{
    public Transform[] SpawnPoint;
    public int playerCount= 0;
    public GameObject Timer;
    public GameObject playerID;

    public SpriteRenderer spriteRenderer;

    


    public void OnPlayerJoined(PlayerInput playerInput)
    {
        spriteRenderer = playerInput.gameObject.GetComponent<SpriteRenderer>();

        int spawnIndex = playerCount;
        playerInput.transform.position = SpawnPoint[spawnIndex].position;
        playerCount++;

        playerID = GameObject.FindWithTag("Joined");
        playerID.tag = "Player" + playerCount;

        if(playerCount==1)
        {
            spriteRenderer.color = Color.blue;
        }
        if (playerCount == 2)
        {
            spriteRenderer.color = Color.red;
            PlayerControls playerControls = GameObject.FindWithTag("Player2").GetComponent<PlayerControls>();

            playerControls.jumpImpulse = 45;
        }


        if (spawnIndex == 1)
        {
            Timer.SetActive(true);
        }
        
        

    }
}
