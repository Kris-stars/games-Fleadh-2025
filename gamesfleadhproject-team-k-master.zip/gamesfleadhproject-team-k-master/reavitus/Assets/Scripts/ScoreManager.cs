using UnityEngine;
using UnityEngine.UI;

public class ScoreManager : MonoBehaviour
{
    public int scoreReached = 7;
    private int player1Score = 0;
    private int player2Score = 0;

    public Text player1ScoreText;
    public Text player2ScoreText;

    public GameObject Restartbutton;
    public Text playerWinner;
    public GameObject ball;

    public void Player1Goal()
    {
        player1Score++;
        player1ScoreText.text = player1Score.ToString();
        CheckScore();
    }

    public void Player2Goal()
    {
        player2Score++;
        player2ScoreText.text = player2Score.ToString();
        CheckScore();
    }

    private void CheckScore()
    {
        if (player1Score == scoreReached )
        {
            playerWinner.text = "Player 1 Wins";
            ball.SetActive(false);
            Restartbutton.SetActive(true);
            playerWinner.color = Color.blue;
        }
        if (player2Score >= scoreReached)
        {
            playerWinner.text = "Player 2 Wins";
            ball.SetActive(false);
            Restartbutton.SetActive(true);
            playerWinner.color = Color.red;
        }
    }
}
