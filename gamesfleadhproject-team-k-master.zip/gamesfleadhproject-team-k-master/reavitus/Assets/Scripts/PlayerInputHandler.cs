using System.Linq;
using UnityEngine;
using UnityEngine.InputSystem;
using static UnityEngine.InputSystem.InputAction;

public class PlayerInputHandler : MonoBehaviour
{
    private PlayerInput playerInput;
    private PlayerControls playerControls;

    [System.Obsolete]
    private void Awake()
    {
        playerInput = GetComponent<PlayerInput>();
        var playerControllers = FindObjectOfType<PlayerControls>();
        var index = playerInput.playerIndex;

        //playerControls = playerControllers.FirstOrDefault(p => p.GetPlayerIndex == index);
    }

    public void OnMove(CallbackContext context)
    {
        playerControls.SetInputVector(context.ReadValue<Vector2>());
    }


}
