using UnityEngine;

public class playeraudiocontoller : MonoBehaviour
{
    public AudioSource footsteps;

    public AudioSource slippysteps;




    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    public void PlayFootsteps(bool walking)
    {
        if (walking && !footsteps.isPlaying)
        {
            footsteps.Play();
        }

        if (!walking)
        {
            footsteps.Stop();
        }

    }

    public void PlaySlippysteps(bool walkingslippy)
    {
        if (walkingslippy && !slippysteps.isPlaying)
        {
            slippysteps.Play();
        }

        if (!walkingslippy)
        {
            slippysteps.Stop();
        }

    }


}
