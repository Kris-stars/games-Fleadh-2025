using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManger : MonoBehaviour
{
    public static GameManger instance;

    void Awake()
    {
        
        
         instance = this;
            
        
    }

    public void ChangeLevelTo(string levelName)
    {
        SceneManager.LoadScene(levelName);
    }
}
