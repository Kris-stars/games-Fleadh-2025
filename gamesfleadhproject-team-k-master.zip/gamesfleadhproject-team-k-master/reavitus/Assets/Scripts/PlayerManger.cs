using UnityEngine;
using System.Collections;

public class PlayerManger : MonoBehaviour
{
    Animator animator;
    PlayerHealth playerHealth;

    public PlayerAudioControl playerAudio;

    

    bool deathTriggred = false;
    public int destoryTimer = 1;

    void Start()
    {
        animator = GetComponent<Animator>();
        playerHealth = GetComponent<PlayerHealth>();

        SpawnManger.Instance.test = "Hello World";
    }

    void Update()
    {
        if (playerHealth.health <= 0 && !deathTriggred)
        {
            animator.SetTrigger("Death");
            deathTriggred = true;

            playerAudio.PlayDeathAudio();

            StartCoroutine(DestroyGameObject(destoryTimer));
        }
    }

    IEnumerator DestroyGameObject(int delayTime)
    {
        yield return new WaitForSeconds(delayTime);

        
        
            
        
        
    }
}