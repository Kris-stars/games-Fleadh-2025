using UnityEngine;

public class powerAudio : MonoBehaviour
{

    public AudioClip powerUpAudio;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
