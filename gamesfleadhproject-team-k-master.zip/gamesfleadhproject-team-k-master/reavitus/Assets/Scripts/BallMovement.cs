using System.Collections;
using UnityEngine;

public class BallMovement : MonoBehaviour
{
    public float ballSpeed;
   
    public float maxSpeed;
    
    public bool player1Start = true;

    


    private Rigidbody2D rb;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();

        StartCoroutine(Launch());

        


    }

    private void Restartball()
    {
        rb.linearVelocity = new Vector2(0, 0); 
        transform.position = new Vector2(0, 0);

        float randomSize = Random.Range(0.5f, 2f);
        transform.localScale = new Vector3(randomSize, randomSize, 1);

        float randomMass = Random.Range(0.5f, 2f);

        rb.mass = randomMass;

    }


    public void MoveBall(Vector2 direction)
    {
        direction = direction.normalized;

        

        rb.linearVelocity = direction * ballSpeed;
    }

    public IEnumerator Launch()
    {
        Restartball();
        

        yield return new WaitForSeconds(1);

        if (player1Start == true)
        {
            MoveBall(new Vector2(-1, 0));
        }
        else
        {
            MoveBall(new Vector2(1, 0));
        }
    }

    
}
