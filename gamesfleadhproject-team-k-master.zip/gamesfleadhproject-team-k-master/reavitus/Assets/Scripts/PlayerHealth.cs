using UnityEngine;
using UnityEngine.UI;

public class PlayerHealth : MonoBehaviour
{
    public int health;
    // health bar
    




    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

    }

    public void Hit(int hitAmount)
    {
        if (health >= 0)
        {
            health = health - hitAmount;

       

        }
    }

   
}
