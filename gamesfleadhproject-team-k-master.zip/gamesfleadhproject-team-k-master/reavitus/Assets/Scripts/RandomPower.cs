using UnityEngine;
using UnityEngine.InputSystem;
using System.Collections;

public class RandomPower : MonoBehaviour
{

    
    public GameObject areaDragleft;
    public GameObject areaDragright;

    public GameObject areaPushTopleft;
    public GameObject areaPushTopright; 
    public GameObject areaPushBottomright;
    public GameObject areaPushBottomleft;

    public GameObject CirclePull;

    public Transform[] powerSpawnPoint;

    public GameObject Powerup;


    public PhysicsMaterial2D sillpy;

    public float lastingTimer = 5f;
    public float currentTimer;

    private int radChaspawn = 0;
    private int radChpower = 0;
    private int radChpowerarea = 0;

    

    public SpriteRenderer spriteRenderer;
    public Sprite fallSprite;
    public Sprite slippySprite;
    public Sprite pushSprite;
    public Sprite slowSprite;
    public Sprite vortexSprite;

    public AudioClip fallAudio;
    public AudioClip slippyAudio;
    public AudioClip pushAudio;
    public AudioClip slowAudio;
    public AudioClip vortexAudio;
    public AudioSource audioSource;

    public GameObject otherPlayer;


    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        currentTimer = lastingTimer;
        Powerup = GameObject.FindWithTag("PowerUp");
        spriteRenderer = gameObject.GetComponent<SpriteRenderer>();
        

    }

        // Update is called once per frame
        void Update()
        {
            currentTimer -= Time.deltaTime;


            if (currentTimer <= 0f)
            {

                radChaspawn = Random.Range(1, 5);
                radChpower = Random.Range(1, 4);
                if (radChpower == 1)
                {
                    spriteRenderer.sprite = fallSprite;
                }
                if (radChpower == 2)
                {
                    spriteRenderer.sprite = slippySprite;
                }
                if (radChpower == 3)
                {
                    radChpowerarea = Random.Range(1, 5);
                    if (radChpowerarea == 1)
                    {
                        spriteRenderer.sprite = slowSprite;
                    
                        
                    }
                    if (radChpowerarea == 2)
                    {
                        spriteRenderer.sprite = pushSprite;
                    
                        
                    }
                    if (radChpowerarea == 3)
                    {
                        spriteRenderer.sprite = pushSprite;
                    
                        
                    }
                    if (radChpowerarea == 4)
                    {
                        spriteRenderer.sprite = vortexSprite;
                    
                        
                    }
                }

                Powerup.transform.position = powerSpawnPoint[radChaspawn].position;
                currentTimer = lastingTimer;


                

            }
        }



    private void OnCollisionEnter2D(Collision2D collision)
    {

        if (collision.gameObject.tag == "Player1" || collision.gameObject.tag == "Player2")
        {

            //areaDrag.SetActive(true);

            //ballMovement.ballSpeed = 4f;
            Powerup.transform.position = powerSpawnPoint[0].position;




            //random chance for flip NOTE never have gravity more than 1 or - 1 it will brake game


            if (radChpower == 1)
            {
                if (collision.gameObject.tag == "Player1")
                {
                    otherPlayer = GameObject.FindWithTag("Player2");
                }
                if (collision.gameObject.tag == "Player2")
                {
                    otherPlayer = GameObject.FindWithTag("Player1");
                }

                Rigidbody2D otherRB = otherPlayer.GetComponent<Rigidbody2D>();

                otherRB.gravityScale = otherRB.gravityScale * -1;

                audioSource.clip = fallAudio;
                audioSource.Play();







            }

            if (radChpower == 2)
            {
                audioSource.clip = slippyAudio;
                audioSource.Play();
                PlayerControls playerControls = collision.gameObject.GetComponent<PlayerControls>();
                if (playerControls.isSlippy == true)
                {
                    playerControls.isSlippy = false;
                }
                else
                {
                    if (collision.gameObject.tag == "Player1")
                    {
                        otherPlayer = GameObject.FindWithTag("Player2");
                    }
                    if (collision.gameObject.tag == "Player2")
                    {
                        otherPlayer = GameObject.FindWithTag("Player1");
                    }
                    PlayerControls otherplayerControls = otherPlayer.GetComponent<PlayerControls>();
                    otherplayerControls.isSlippy = true;
                }
            }

            if (radChpower == 3)
            {

                if (collision.gameObject.tag == "Player1")
                {


                    if (radChpowerarea == 1)
                    {
                        audioSource.clip = slowAudio;
                        audioSource.Play();
                        areaDragright.SetActive(true);
                        StartCoroutine(DisableAfterTime(areaDragright, 16f));

                    }
                    if (radChpowerarea == 2)
                    {
                        audioSource.clip = pushAudio;
                        audioSource.Play();
                        areaPushTopright.SetActive(true);
                        StartCoroutine(DisableAfterTime(areaPushTopright, 16f));

                    }
                    if (radChpowerarea == 3)
                    {
                        audioSource.clip = pushAudio;
                        audioSource.Play();
                        areaPushBottomright.SetActive(true);
                        StartCoroutine(DisableAfterTime(areaPushBottomright, 16f));

                    }
                    if (radChpowerarea == 4)
                    {
                        audioSource.clip = vortexAudio;
                        audioSource.Play();
                        CirclePull.SetActive(true);
                        StartCoroutine(DisableAfterTime(CirclePull, 16f));

                    }
                }

                if (collision.gameObject.tag == "Player2")
                {

                    if (radChpowerarea == 1)
                    {
                        audioSource.clip = slowAudio;
                        audioSource.Play();
                        areaDragleft.SetActive(true);
                        StartCoroutine(DisableAfterTime(areaDragleft, 16f));

                    }
                    if (radChpowerarea == 2)
                    {
                        audioSource.clip = pushAudio;
                        audioSource.Play();
                        areaPushTopleft.SetActive(true);
                        StartCoroutine(DisableAfterTime(areaPushTopleft, 16f));

                    }
                    if (radChpowerarea == 3)
                    {
                        audioSource.clip = pushAudio;
                        audioSource.Play();
                        areaPushBottomleft.SetActive(true);
                        StartCoroutine(DisableAfterTime(areaPushBottomleft, 16f));

                    }
                    if (radChpowerarea == 4)
                    {
                        audioSource.clip = vortexAudio;
                        audioSource.Play();
                        CirclePull.SetActive(true);
                        StartCoroutine(DisableAfterTime(CirclePull, 16f));

                    }
                }

            }
        }
    }

    private IEnumerator DisableAfterTime(GameObject area, float time)
    {
        yield return new WaitForSeconds(time);
        area.SetActive(false);
    }



    //int RadCha = Random.Range(1, 2);
    //if (RadCha == 1)
    //{
    //    areaDragleft.SetActive(false);
    //}
    //else
    //{
    //    areaDragleft.SetActive(true);
    //}



    //if (RadCha == 5)
    //{
    //    sillpy.friction = 0f;

    //}
    //if (RadCha == 5)
    //{
    //    sillpy.friction = 1f;

    //}


    //if (RadCha == 4)
    //{
    //    int RadCha = Random.Range(1, 5);
    //    BallMovement ballMovement = collision.gameObject.GetComponent<BallMovement>();

    //    ballMovement.startSpeed = RadCha;
    //}
    //if (RadCha == 5)
    //{
    //    int RadCha = Random.Range(1, 3);
    //    BallMovement ballMovement = collision.gameObject.GetComponent<BallMovement>();

    //    ballMovement.maxExtraSpeed = RadCha;
    //}

    //if (RadCha == 2)
    //{
    //    int RadCha = Random.Range(5, 10);
    //    PlayerControls playerControls = collision.gameObject.GetComponent<PlayerControls>();

    //    playerControls.moveSpeed = RadCha;
    //}
    //if (RadCha == 3)
    //{
    //    int RadCha = Random.Range(10, 30);
    //    PlayerControls playerControls = collision.gameObject.GetComponent<PlayerControls>();

    //    playerControls.jumpImpulse = RadCha;

    //}






}


    

   

