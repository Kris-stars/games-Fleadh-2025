using UnityEngine;

[RequireComponent(typeof(CapsuleCollider2D))]
public class GroundCheck : MonoBehaviour
{
    CapsuleCollider2D capsuleCollider2D;
    public ContactFilter2D cast;
    public float groundDistance = 0.05F;
    RaycastHit2D[] raycastHit2D = new RaycastHit2D[5];
    public bool isGrounded = false;

    private Rigidbody2D rb;

    // Start is called before the first frame update
    void Start()
    {
        capsuleCollider2D = gameObject.GetComponent<CapsuleCollider2D>();

    }

    // Update is called once per frame
    void FixedUpdate()
    {

        int collisionsdown = capsuleCollider2D.Cast(Vector2.down, cast, raycastHit2D, groundDistance);
        int collisionsup = capsuleCollider2D.Cast(Vector2.up, cast, raycastHit2D, groundDistance);

        // If we collide with the ground
        if (collisionsdown > 0)
        {
            isGrounded = true;

        }
        else if (collisionsup > 0) 
        {
            isGrounded = true;
        }
 
        // if we're not colliding with the ground (jumping)
        else
        {
            isGrounded = false;
        }
    }
}
