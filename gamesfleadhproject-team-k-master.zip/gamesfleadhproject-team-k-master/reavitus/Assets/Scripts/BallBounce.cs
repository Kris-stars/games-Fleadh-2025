using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BallBounce : MonoBehaviour
{
    public BallMovement ballMovement;
    public ScoreManager scoreManager;
    
    public PhysicsMaterial2D ballMaterial;

    public AudioSource myAudioSource;
    public AudioClip bounceclip;
    public AudioClip scoreclip;


    private void Bounce(Collider2D collision)
    {
        Vector3 ballPostion = transform.position;
        Vector3 playerPostion = collision.transform.position;
        float playerHeight = collision.bounds.size.y;

        float positionX;
        if (collision.gameObject.tag == "Player1")
        {
            positionX = 1;
        }
        else
        {
            positionX = -1;
        }

        float positionY = (ballPostion.y - playerPostion.y) / playerHeight;


        ballMovement.MoveBall(new Vector2(positionX, positionY));


    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        myAudioSource.PlayOneShot(bounceclip);
        if (collision.gameObject.tag == "Player1" || collision.gameObject.tag == "Player2")
        {

            Bounce(collision.collider);
        }

        else if (collision.gameObject.name == "Left Goal")
        {
            myAudioSource.PlayOneShot(scoreclip);
            scoreManager.Player2Goal();
            ballMovement.player1Start = false;
            StartCoroutine(ballMovement.Launch());

        }
        else if (collision.gameObject.name == "Right Goal")
        {
            myAudioSource.PlayOneShot(scoreclip);
            scoreManager.Player1Goal();
            ballMovement.player1Start = true;
            StartCoroutine(ballMovement.Launch());

        }
    }
}
