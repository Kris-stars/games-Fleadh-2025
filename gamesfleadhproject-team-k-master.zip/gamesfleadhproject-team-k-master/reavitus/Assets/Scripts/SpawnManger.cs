using UnityEngine;

public class SpawnManger : MonoBehaviour
{

    
       public static SpawnManger Instance { get; private set; }

    public string test = "test";
    

    private void Awake()
    {
        // If there is an instance, and it's not me, delete myself.

        if (Instance != null && Instance != this)
        {
            Destroy(this);
        }
        else
        {
            Instance = this;
        }
    }


    // Update is called once per frame
    void Update()
    {
        
    }
}
