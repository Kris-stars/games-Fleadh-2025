using UnityEngine;
using UnityEngine.UI;
using System.Collections;


public class TimerScript : MonoBehaviour
{

    public float startTimer = 8f;
    public float currentTimer;
    public GameObject Ball;
    public GameObject Timer;
    

    public Text timerText;

    void Start()
    {
        currentTimer = startTimer;
        
    }

    // Update is called once per frame
    void Update()
    {
            currentTimer -= Time.deltaTime;

            //int minutes = Mathf.FloorToInt(timer / 60F);
            //int seconds = Mathf.FloorToInt(timer - minutes * 60);
            //string niceTime = string.Format("{0:0}:{1:00}", minutes, seconds);
            //timerText.text = niceTime;
            timerText.text = Mathf.Floor(currentTimer).ToString();

            if (currentTimer <= 0f)
            {
                Ball.SetActive(true);
                Timer.SetActive(false);
             }

    }
}
