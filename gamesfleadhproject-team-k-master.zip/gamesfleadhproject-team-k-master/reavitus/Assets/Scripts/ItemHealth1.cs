using UnityEngine;

public class ItemHealth1 : MonoBehaviour
{
    public int health = 2;


    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

    }

    public void Hit(int hitAmount)
    {
        if (health >= 0)
        {
            health = health - hitAmount;

            Debug.Log("Hit");
        }
    }
}
