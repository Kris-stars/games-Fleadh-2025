using UnityEngine;
using UnityEngine.InputSystem;
using System.Collections;
using System;

public class PlayerControls : MonoBehaviour
{
    [SerializeField]
    private int playerIndex = 0;

    private Rigidbody2D rb;

    public int moveSpeed = 1;

    public int jumpImpulse = 3;

    private Vector2 moveInput;

    private Animator animator;

    private SpriteRenderer spriteRenderer;

    GroundCheck groundCheck;

    public playeraudiocontoller playerAudio;

    public AudioSource jumpSource;

    public AudioClip jumpClip;

    private bool jumpClipPlayed = false;

    public GameObject walkparticalsdown;
    public GameObject walkparticalsup;


    public bool isSlippy = false;

    public int GetPlayerIndex()
    {
        return playerIndex;
    }



    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        rb = gameObject.GetComponent<Rigidbody2D>();

        animator = gameObject.GetComponent<Animator>();

        spriteRenderer = gameObject.GetComponent<SpriteRenderer>();

        groundCheck = gameObject.GetComponent<GroundCheck>();

        
    }

    

    // Update is called once per frame
    void Update()
    {

        // Move the Player on the X axis only

        if (rb.gravityScale <= -1)
        {
            spriteRenderer.flipY = true;

            if (!groundCheck.isGrounded)
            {
                animator.SetBool("Jump", true);
                walkparticalsdown.SetActive(false);
                walkparticalsup.SetActive(false);


                if (!jumpClipPlayed)
                {
                    jumpSource.PlayOneShot(jumpClip);
                    jumpClipPlayed = true;
                }
                if (isSlippy)
                {
                    playerAudio.PlaySlippysteps(true);
                }
                else
                {
                    playerAudio.PlayFootsteps(true);
                }
            

                if (moveInput.x < 0)
                {
                    spriteRenderer.flipX = true;
                }
                else
                {
                    spriteRenderer.flipX = false;
                }
            }
            else
            {

                animator.SetBool("Jump", false);
                jumpClipPlayed = false;
                walkparticalsdown.SetActive(true);
                walkparticalsup.SetActive(false);

            }

            if (moveInput != Vector2.zero && groundCheck.isGrounded)
            {
                animator.SetBool("Jump", false);

                animator.SetBool("Walking", true);


                if (isSlippy)
                {
                    playerAudio.PlaySlippysteps(true);
                }
                else
                {
                    playerAudio.PlayFootsteps(true);
                }

                if (moveInput.x < 0)
                {
                    spriteRenderer.flipX = true;
                }
                else
                {
                    spriteRenderer.flipX = false;
                }
            }
            else
            {
                animator.SetBool("Walking", false);

                playerAudio.PlayFootsteps(false);
                playerAudio.PlaySlippysteps(false);

            }


        }
        else
        {
            spriteRenderer.flipY = false;

            if (!groundCheck.isGrounded)
            {
                animator.SetBool("Jump", true);
                walkparticalsdown.SetActive(false);
                walkparticalsup.SetActive(false);

                if (!jumpClipPlayed)
                {
                    jumpSource.PlayOneShot(jumpClip);
                    jumpClipPlayed = true;
                }


                playerAudio.PlayFootsteps(false);
                playerAudio.PlaySlippysteps(false);

                if (moveInput.x < 0)
                {
                    spriteRenderer.flipX = true;
                }
                else
                {
                    spriteRenderer.flipX = false;
                }
            }
            else
            {

                animator.SetBool("Jump", false);
                jumpClipPlayed = false;
                walkparticalsdown.SetActive(false);
                walkparticalsup.SetActive(true);

            }

            if (moveInput != Vector2.zero && groundCheck.isGrounded)
            {
                animator.SetBool("Jump", false);

                animator.SetBool("Walking", true);

                if (isSlippy)
                {
                    playerAudio.PlaySlippysteps(true);
                }
                else
                {
                    playerAudio.PlayFootsteps(true);
                }


                if (moveInput.x < 0)
                {
                    spriteRenderer.flipX = true;
                }
                else
                {
                    spriteRenderer.flipX = false;
                }
            }
            else
            {
                animator.SetBool("Walking", false);

                playerAudio.PlayFootsteps(false);
                playerAudio.PlaySlippysteps(false);

            }
        }


        
         

        

        
        

        

    }

    void FixedUpdate()
    {
        if (isSlippy)
        {
            rb.AddForce(new Vector2((moveInput.x * moveSpeed), 0), ForceMode2D.Force);
            rb.linearVelocity = new Vector2(Mathf.Clamp(rb.linearVelocity.x, -moveSpeed, moveSpeed), rb.linearVelocity.y);
        }
        else
        {
            rb.linearVelocity = new Vector2((moveInput.x * moveSpeed), rb.linearVelocity.y);
            rb.linearVelocity = new Vector2(Mathf.Clamp(rb.linearVelocity.x, -moveSpeed, moveSpeed), rb.linearVelocity.y);
        }

            

    }

    void OnMove(InputValue movementValue)
    {

        moveInput = movementValue.Get<Vector2>();
    }

    //void OnFire()
    //{
       
    //    if (moveInput == Vector2.zero)
    //    {
    //        animator.SetTrigger("Attack");

    //        //playerAudio.PlayAttackAudio();


    //    }
    //}

    void OnJump()
    {
        
        // Trigger the Jump Animation
        if (groundCheck.isGrounded)
        {


            if (rb.gravityScale >= 1)
            {


                //rb.linearVelocity = new Vector2(rb.linearVelocity.x, jumpImpulse);
                rb.AddForce(Vector2.up * jumpImpulse, ForceMode2D.Impulse);


            }

            if (rb.gravityScale < 1)
            {

                //rb.linearVelocity = new Vector2(rb.linearVelocity.x, jumpImpulse * -1);
                rb.AddForce(Vector2.up * jumpImpulse *-1, ForceMode2D.Impulse);


            }
        }


    }

    internal void SetInputVector(Vector3 vector3)
    {
        throw new NotImplementedException();
    }

    internal PlayerControls FirstOrDefault(Func<object, bool> value)
    {
        throw new NotImplementedException();
    }
}


