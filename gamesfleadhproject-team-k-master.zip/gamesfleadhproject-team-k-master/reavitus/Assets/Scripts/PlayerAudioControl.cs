using UnityEngine;

public class PlayerAudioControl : MonoBehaviour
{

    public AudioSource walkingAudio;

    public AudioSource attackAudio;

    public AudioSource deathAudio;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void PLayerWalkingAudio(bool walking)
    {
        if (walking && !walkingAudio.isPlaying)
        {
            walkingAudio.Play();
        }
        if (!walking)
        {
            walkingAudio.Stop();
        }
    }

    public void PlayAttackAudio()
    {
        attackAudio.Play();
    }

    public void PlayDeathAudio()
    {
        deathAudio.Play();
    }

}
