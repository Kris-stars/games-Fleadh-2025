cool test works

